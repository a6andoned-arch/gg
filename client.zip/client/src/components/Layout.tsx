import { Link, useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { Sparkles, Moon, Sun, Stars, Menu, X, CircleDot, Hash } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";

export function Layout({ children }: { children: React.ReactNode }) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [location] = useLocation();

  const navItems = [
    { label: "Home", href: "/", icon: <Stars className="w-4 h-4" /> },
    { label: "Tarot", href: "/tarot", icon: <Moon className="w-4 h-4" /> },
    { label: "Fortune Ball", href: "/fortune-ball", icon: <CircleDot className="w-4 h-4" /> },
    { label: "Kundali", href: "/kundali", icon: <Sun className="w-4 h-4" /> },
    { label: "Numerology", href: "/numerology", icon: <Hash className="w-4 h-4" /> },
    { label: "Dark Magic", href: "/dark-magic", icon: <Moon className="w-4 h-4" /> },
  ];

  return (
    <div className="min-h-screen flex flex-col font-sans relative overflow-x-hidden">
      {/* Mystic Ambient Background Elements */}
      <div className="fixed top-[-20%] left-[-10%] w-[50%] h-[50%] bg-primary/5 rounded-full blur-[120px] pointer-events-none" />
      <div className="fixed bottom-[-20%] right-[-10%] w-[50%] h-[50%] bg-accent/5 rounded-full blur-[120px] pointer-events-none" />

      {/* Navigation */}
      <header className="sticky top-0 z-[100] w-full border-b border-primary/10 bg-black/95 backdrop-blur-md shadow-[0_4px_20px_rgba(0,0,0,0.8)]">
        <div className="container mx-auto px-4 h-20 flex items-center justify-between gap-8">
          <Link href="/" className="flex items-center group cursor-pointer shrink-0">
            <div className="relative p-2 rounded-lg bg-white/15 backdrop-blur-md border border-white/20 shadow-[0_0_15px_rgba(255,255,255,0.1)] transition-all duration-300 group-hover:bg-white/20 group-hover:border-white/30">
              <img 
                src="https://i.ibb.co/4wf90k3q/Dark-Magic.png" 
                className="h-12 w-auto object-contain transition-transform duration-500 group-hover:scale-105" 
                alt="Dark Magic" 
              />
            </div>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden lg:flex items-center gap-4 xl:gap-6 whitespace-nowrap overflow-x-visible">
            {navItems.map((item) => (
              <Link 
                key={item.href} 
                href={item.href}
                className={`
                  flex items-center gap-2 text-sm font-medium transition-colors hover:text-primary py-2
                  ${location === item.href ? "text-primary border-b-2 border-primary" : "text-muted-foreground"}
                `}
              >
                <span className="shrink-0">{item.icon}</span>
                <span>{item.label}</span>
              </Link>
            ))}
          </nav>

          {/* Mobile Menu Toggle */}
          <Button 
            variant="ghost" 
            size="icon" 
            className="lg:hidden text-primary hover:bg-white/5"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X /> : <Menu />}
          </Button>
        </div>

        {/* Mobile Nav Dropdown */}
        <AnimatePresence>
          {isMobileMenuOpen && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="lg:hidden border-t border-white/5 bg-background/95 backdrop-blur-xl overflow-hidden"
            >
              <nav className="flex flex-col p-4 gap-4">
                {navItems.map((item) => (
                  <Link 
                    key={item.href} 
                    href={item.href}
                    onClick={() => setIsMobileMenuOpen(false)}
                    className={`
                      flex items-center gap-3 p-3 rounded-lg transition-colors
                      ${location === item.href ? "bg-primary/10 text-primary" : "text-muted-foreground hover:bg-white/5"}
                    `}
                  >
                    {item.icon}
                    {item.label}
                  </Link>
                ))}
              </nav>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      {/* Main Content */}
      <main className="flex-1 container mx-auto px-4 py-8 relative z-10">
        <AnimatePresence mode="wait">
          <motion.div
            key={location}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.4, ease: "easeOut" }}
          >
            {children}
          </motion.div>
        </AnimatePresence>
      </main>

      <footer className="border-t border-white/5 bg-black/20 mt-auto">
        <div className="container mx-auto px-4 py-8 text-center">
          <div className="mb-10">
            <a 
              href="https://tango.me/voido" 
              target="_blank" 
              rel="noopener noreferrer"
              className="inline-flex items-center gap-3 px-10 py-4 border-2 border-primary/50 bg-black/40 text-primary rounded-full font-display text-lg hover:bg-primary hover:text-black transition-all duration-300 shadow-[0_0_25px_rgba(212,175,55,0.15)] hover:shadow-[0_0_35px_rgba(212,175,55,0.4)] transform hover:scale-105"
            >
              <Sparkles className="w-6 h-6" />
              Support the Shadows
            </a>
          </div>
          <div className="text-muted-foreground text-sm font-display flex flex-col items-center gap-4">
            <div className="flex justify-center gap-4 text-xs opacity-60">
              <span>Tarot Readings</span> • 
              <span>Vedic Kundali</span> • 
              <span>Numerology Insights</span> •
              <span>Shadow Search</span>
            </div>
            <p className="opacity-40">© {new Date().getFullYear()} Dark Magic. Unveil your destiny.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
